package edu.pitt.ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.JButton;

import edu.pitt.bank.*;
import edu.pitt.utilities.DbUtilities;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class AccountDetails {

	private JFrame frAccountDetails;
	private JLabel lblRoles;
	private JLabel lblNewLabel;
	private JLabel lblYourAccounts;
	private JTextField txtAmount;

	/**
	 * Launch the application.
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AccountDetails window = new AccountDetails();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	**/
	
	/**
	 * Create the application.
	 */
	public AccountDetails(Customer c) {
		initialize(c);
		frAccountDetails.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(Customer c) {
		frAccountDetails = new JFrame();
		frAccountDetails.setBounds(100, 100, 456, 300);
		frAccountDetails.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frAccountDetails.getContentPane().setLayout(null);
		
		String accountID = "";
		
		final JComboBox cboAccount = new JComboBox();
		cboAccount.setBounds(124, 79, 261, 20);
		
		
		//Retreiving accountID from Customer object
		String sql = "SELECT * FROM qnn1_bank1017.account, qnn1_bank1017.customer, qnn1_bank1017.customer_account "; 
		sql += "WHERE qnn1_bank1017.customer.customerID = qnn1_bank1017.customer_account.fk_customerID ";
		sql += "AND qnn1_bank1017.account.accountID = qnn1_bank1017.customer_account.fk_accountID ";
		sql += "AND qnn1_bank1017.customer.customerID = '" + c.getCustomerID() + " ';";
		
		DbUtilities db = new DbUtilities();
		
		//Store account(s) of the user
		ArrayList<Account> accountList = new ArrayList<Account>();
		try {
			ResultSet rs = db.getResultSet(sql);
			while(rs.next()){
				Account a = new Account(rs.getString("accountID"));
				accountList.add(a);
				cboAccount.addItem(a);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 444, 262);
		frAccountDetails.getContentPane().add(panel);
		panel.setLayout(null);
		
		panel.add(cboAccount);
		
		JLabel lblPermission = new JLabel("You have the following permissons:");
		lblPermission.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblPermission.setBounds(24, 42, 215, 14);
		panel.add(lblPermission);
		
		lblRoles = new JLabel("New label");
		lblRoles.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblRoles.setBounds(258, 42, 46, 14);
		panel.add(lblRoles);
		
		lblNewLabel = new JLabel(c.getFirstName());
		lblNewLabel.setBounds(24, 11, 46, 14);
		panel.add(lblNewLabel);
		
		lblYourAccounts = new JLabel("Your accounts:");
		lblYourAccounts.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblYourAccounts.setBounds(24, 82, 103, 14);
		panel.add(lblYourAccounts);
		
		
		
		
		JLabel lblAccountType = new JLabel("Account type:");
		lblAccountType.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblAccountType.setBounds(24, 110, 79, 14);
		panel.add(lblAccountType);
		
		JLabel lblBalance = new JLabel("Balance:");
		lblBalance.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblBalance.setBounds(24, 122, 79, 14);
		panel.add(lblBalance);
		
		JLabel lblInterestRate = new JLabel("Interest Rate:");
		lblInterestRate.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblInterestRate.setBounds(24, 135, 79, 14);
		panel.add(lblInterestRate);
		
		//Account type
		final JLabel lblDynamicAccount = new JLabel();
		lblDynamicAccount.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDynamicAccount.setBounds(114, 110, 64, 14);
		panel.add(lblDynamicAccount);
		
		//Account balance
		final JLabel lblDynamicBalance = new JLabel();		
		lblDynamicBalance.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDynamicBalance.setText("balance holer");
		lblDynamicBalance.setBounds(93, 122, 67, 14);
		panel.add(lblDynamicBalance);
		
		//Account rate
		final JLabel lblDynamicRate = new JLabel("rate");
		lblDynamicRate.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDynamicRate.setBounds(109, 137, 69, 11);
		panel.add(lblDynamicRate);
		
		//Account penalty
		final JLabel lblDynamicPenalty = new JLabel("penalty");
		lblDynamicPenalty.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDynamicPenalty.setBounds(81, 147, 46, 14);
		panel.add(lblDynamicPenalty);
		
		JLabel lblBalance_1 = new JLabel("Penalty");
		lblBalance_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblBalance_1.setBounds(24, 147, 46, 14);
		panel.add(lblBalance_1);
		
		JLabel lblAmount = new JLabel("Amount:");
		lblAmount.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblAmount.setBounds(199, 110, 68, 14);
		panel.add(lblAmount);
		
		txtAmount = new JTextField();
		txtAmount.setBounds(277, 110, 124, 20);
		panel.add(txtAmount);
		txtAmount.setColumns(10);
		
		JButton btnDeposit = new JButton("Deposit");
		btnDeposit.setBounds(194, 144, 89, 23);
		panel.add(btnDeposit);
		
		
		JButton btnWithdraw = new JButton("Withdraw");
		btnWithdraw.setBounds(312, 144, 89, 23);
		panel.add(btnWithdraw);
		
		JButton btnShowTransaction = new JButton("Show Transactions\r\n");
		btnShowTransaction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnShowTransaction.setBounds(140, 199, 152, 23);
		panel.add(btnShowTransaction);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(312, 199, 89, 23);
		panel.add(btnExit);
		
		//Update account's fields
		Account a = (Account)cboAccount.getSelectedItem();
		lblDynamicAccount.setText(a.getType());
		lblDynamicBalance.setText(("$" + Double.toString(a.getBalance())));
		lblDynamicRate.setText((Double.toString(100 * a.getInterestRate())) + "%");
		lblDynamicPenalty.setText(("$" + Double.toString(a.getPenalty())));
	
		//Changing label according to account.
		cboAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Account a = (Account)cboAccount.getSelectedItem();
				lblDynamicAccount.setText(a.getType());
				lblDynamicBalance.setText(("$" + Double.toString(a.getBalance())));
				lblDynamicRate.setText((Double.toString(100 * a.getInterestRate())) + "%");
				lblDynamicPenalty.setText(("$" + Double.toString(a.getPenalty())));
			}
		});
		
		//Deposit operation.
		btnDeposit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					double amount = Double.parseDouble(txtAmount.getText());
					Account a = (Account)cboAccount.getSelectedItem();
					a.setBalance(amount + a.getBalance());
				}
				catch (Exception ex){
					JOptionPane.showMessageDialog(null, "Invalid Operation");
				}
			}
		});	
	}
}
