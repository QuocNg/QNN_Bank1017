package edu.pitt.ui;

import javax.swing.*;

import edu.pitt.bank.Security;

import java.awt.event.*;
import java.awt.*;
import java.sql.SQLException;

import edu.pitt.bank.*;

public class LoginUI {

	private JFrame frmBankLogin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginUI window = new LoginUI();
					window.frmBankLogin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmBankLogin = new JFrame();
		frmBankLogin.setTitle("Bank Login");
		frmBankLogin.getContentPane().setBackground(Color.WHITE);
		frmBankLogin.setBounds(100, 100, 482, 221);
		frmBankLogin.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frmBankLogin.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(0, 0, 476, 189);
		frmBankLogin.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblLogin = new JLabel("Login Name");
		lblLogin.setBounds(25, 48, 90, 14);
		panel.add(lblLogin);
		
		final JTextArea txtName = new JTextArea();
		txtName.setBounds(98, 48, 267, 14);
		panel.add(txtName);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(25, 73, 90, 14);
		panel.add(lblPassword);
		
		final JTextArea txtPassword = new JTextArea();
		txtPassword.setBounds(98, 73, 267, 14);
		panel.add(txtPassword);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBounds(108, 125, 89, 23);
		panel.add(btnLogin);
		
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
					Security s = new Security();
					String name = txtName.getText();
				
					int pin = Integer.parseInt(txtPassword.getText());
					
					Customer c = s.validateLogin(name, pin);
					
					if(c != null){
						AccountDetails acc = new AccountDetails(c);
						frmBankLogin.setVisible(false);
					
					}
					else{
						JOptionPane.showMessageDialog(null, "Invalid Login");
					}
				}
				catch (Exception ex) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, "Invalid Login");
				}
			
				
			}
		});
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(245, 125, 96, 23);
		panel.add(btnExit);
		
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}		
		});
	}
}
