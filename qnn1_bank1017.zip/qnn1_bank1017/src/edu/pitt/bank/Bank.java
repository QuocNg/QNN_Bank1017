package edu.pitt.bank;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import edu.pitt.utilities.DbUtilities;

public class Bank {
	
	private ArrayList<Account> accountList = new ArrayList<Account>;
	private ArrayList<Customer> customerList = new ArrayList<Customer>;
	
	public Bank ()
	{
		loadAccounts();
		setAccountOwners();
	
	}
	
	private void loadAccounts() {
		String sql = "SELECT accountID FROM qnn1_bank1017.account "; 
		
		DbUtilities db = new DbUtilities();
		db.executeQuery(sql);
		
		try {
			ResultSet rs = db.getResultSet(sql);
			while(rs.next()){
				accountList.add(new Account(rs.getString("accountID")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
	}
	
	private AccountAccount findAccount(String accountID){
		int index = 0; 
		while(accountList.size() > index)
		{
			if(accountList.get(index).getAccountId())
				return accountList.get(index);
			else
				index++;
		}	
		
	}
	
	private void setAccountOwners() {
		String sql = "SELECT customerID FROM qnn1_bank1017.customer "; 
		
		DbUtilities db = new DbUtilities();
		db.executeQuery(sql);
		
		try {
			ResultSet rs = db.getResultSet(sql);
			while(rs.next()){
				Customer temp = new Customer(rs.getString("customerID"));
				customerList.add(temp);
				Account.addAccountOwner(temp);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
	}
}
