package edu.pitt.bank;

public class Tester {
	public static void main(String[] args) {
		String sql = "INSERT INTO qnn1_bank1017.transaction ";
		sql += "(customerID, lastName, firstName, ssn, loginName, pin) ";
		sql += " VALUES ";
		sql += "('" + "x" + "', ";
		sql += "'" + "y" + "', ";
		sql += "'" + "z" + "', ";
		sql += "'" + "b" + "', ";
		sql += "'" + "t" + "', ";
		sql += "'" + "l" + "'); ";
		sql += "CURDATE());";
		
		System.out.println(sql);
	}

}
