package edu.pitt.bank;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.UUID;

import edu.pitt.utilities.DbUtilities;

public class Customer {
	private String customerID;
	private String firstName;
	private String lastName;
	private String ssn;
	private String streetAddress;
	private String city;
	private String state;
	private int zip;
	private String loginName;
	private int pin;
	
	public Customer(String customerID){
		String sql = "SELECT * FROM qnn1_bank1017.customer "; 
		sql += "WHERE customerID = '" + customerID + "'";
		
		DbUtilities db = new DbUtilities();
		try {
			ResultSet rs = db.getResultSet(sql);
			while(rs.next()){
				this.setCustomerID(rs.getString("customerID"));
				this.setFirstName(rs.getString("firstName"));
				this.setLastName(rs.getString("lastName"));
				this.setSsn(rs.getString("ssn"));
				this.setStreetAddress(rs.getString("streetAddress"));
				this.setCity(rs.getString("city"));
				this.setState(rs.getString("state"));
				this.setZip(rs.getInt("zip"));
				this.setLoginName(rs.getString("loginName"));
				this.setPin(rs.getInt("pin"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Customer(String lastName, String firstName, String ssn, String loginName, 
				String city, String state, String streetAddress, int zip, int pin){
		this.setCustomerID(UUID.randomUUID().toString());
		this.setLastName(lastName);
		this.setFirstName(firstName);
		this.setSsn(ssn);
		this.setLoginName(loginName);
		this.setPin(pin);
		this.setCity(city);
		this.setState(state);
		this.setStreetAddress(streetAddress);
		this.setZip(zip);
		
		String sql = "INSERT INTO qnn1_bank1017.customer ";
		sql += "(customerID, lastName, firstName, ssn, loginName, pin) ";
		sql += " VALUES ";
		sql += "('" + this.getCustomerID() + "', ";
		sql += "'" + this.getLastName() + "', ";
		sql += "'" + this.getFirstName() + "', ";
		sql += "'" + this.getSsn() + "', ";
		sql += "'" + this.getLoginName() + "', ";
		sql += "'" + this.getPin() + "'); ";
		
		System.out.println(sql);
		
		DbUtilities db = new DbUtilities();
		db.executeQuery(sql);
	}

	public String getCustomerID() {
		return customerID;
	}

	private void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	public String getSsn() {
		return ssn;
	}

	private void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getLastName() {
		return lastName;
	}

	private void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	private void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	private void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getLoginName() {
		return loginName;
	}

	private void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public int getPin() {
		return pin;
	}

	private void setPin(int pin) {
		this.pin = pin;
	}

	public int getZip() {
		return zip;
	}

	private void setZip(int zip) {
		this.zip = zip;
	}

	public String getState() {
		return state;
	}

	private void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	private void setCity(String city) {
		this.city = city;
	}
	
	
	
}
