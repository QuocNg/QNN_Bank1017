package edu.pitt.bank;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

import edu.pitt.utilities.DbUtilities;

public class Account {
	private String accountID;
	private String type;
	private double balance;
	private double interestRate;
	private double penalty;
	private String status;
	private Date dateOpen;
	private ArrayList<Transaction> transactionList = new ArrayList<Transaction>();
	private ArrayList<Customer> accountOwners = new ArrayList<Customer>();
	
	public Account(String accountID){
		String sql = "SELECT * FROM qnn1_bank1017.account "; 
		sql += "WHERE accountID = '" + accountID + "'";
		DbUtilities db = new DbUtilities();
		try {
			ResultSet rs = db.getResultSet(sql);
			while(rs.next()){
				this.accountID = rs.getString("accountID");
				this.setType(rs.getString("type"));
				this.setBalance(rs.getDouble("balance"));
				this.setInterestRate(rs.getDouble("interestRate"));
				this.setPenalty(rs.getDouble("penalty"));
				this.status = rs.getString("status");
				this.dateOpen = new Date();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Account(String accountType, double initialBalance){
		this.accountID = UUID.randomUUID().toString();
		this.setType(accountType);
		this.setBalance(initialBalance);
		this.setInterestRate(0);
		this.setPenalty(0);
		this.status = "active";
		this.dateOpen = new Date();
		
		String sql = "INSERT INTO qnn1_bank1017.account ";
		sql += "(accountID,type,balance,interestRate,penalty,status,dateOpen) ";
		sql += " VALUES ";
		sql += "('" + this.accountID + "', ";
		sql += "'" + this.getType() + "', ";
		sql += this.getBalance() + ", ";
		sql += this.getInterestRate() + ", ";
		sql += this.getPenalty() + ", ";
		sql += "'" + this.status + "', ";
		sql += "CURDATE());";
		
		DbUtilities db = new DbUtilities();
		db.executeQuery(sql);
	}
	
	
	public void withdraw(double amount){
		this.setBalance(this.getBalance() - amount);
		createTransaction(this.accountID, this.getType(), amount, this.getBalance());
		updateDatabaseAccountBalance();
	}
	
	
	public void deposit(double amount){
		this.setBalance(this.getBalance() + amount);
		createTransaction(this.accountID, this.getType(), amount, this.getBalance());
		updateDatabaseAccountBalance();
	}
	
	private void updateDatabaseAccountBalance(){
		String sql = "UPDATE bank1017.account SET balance = " + this.getBalance() + " ";
		sql += "WHERE accountID = '" + this.accountID + "';";
		
		DbUtilities db = new DbUtilities();
		db.executeQuery(sql);
	}
	
	private Transaction createTransaction(String transactionID){
		Transaction t = new Transaction(transactionID);
		transactionList.add(t);
		return t;
	}
	
	private Transaction createTransaction(String accountID, String type, double amount, double balance){
		Transaction t = new Transaction(accountID, type, amount, balance);
		transactionList.add(t);
		return t;
	}
	
	public String getAccountID(){
		return this.accountID;
	}
	
	public double getBalance(){
		return this.balance;
	}
	
	public void addAccountOwner(Customer accountOwner){
		accountOwners.add(accountOwner);
	}

	public String getType() {
		return type;
	}

	private void setType(String type) {
		this.type = type;
	}

	public double getInterestRate() {
		return interestRate;
	}

	private void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public double getPenalty() {
		return penalty;
	}

	private void setPenalty(double penalty) {
		this.penalty = penalty;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
}
