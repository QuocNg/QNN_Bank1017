package edu.pitt.bank;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import edu.pitt.utilities.DbUtilities;

public class Security {
	
	private String userId;
	
	public Customer validateLogin (String loginName, int pin){
		String sql = "SELECT * FROM qnn1_bank1017.customer WHERE loginName = '" + loginName;
		sql+= "' and pin = " + pin + ";";
		DbUtilities db = new DbUtilities();
		try {
			ResultSet rs = db.getResultSet(sql);
			if(rs.next()){
				
					return new Customer(rs.getString("customerID"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}
	
	public ArrayList<String> listUserGroups(String userID) {
		return null;
	}

}
